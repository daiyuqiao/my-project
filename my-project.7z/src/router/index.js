import Vue from 'vue'
import Router from 'vue-router'

const Layout = () => import('@/view/layout')
const superAdmin = () => import('@/view/superAdmin')
const systemTools = () => import('@/view/systemTools')
const autoCode = () => import('@/view/systemTools/autoCode')
const formCreate = () => import('@/view/systemTools/formCreate')

Vue.use(Router)

const baseRouters = [
    {
        path: '/',
        component: Layout,
        children: [
            {
                path: '/superAdmin',
                name: 'superAdmin',
                component: superAdmin,
                meta: {
                    title: '超级管理员',
                    keepAlive: true
                }
            }
        ]
    },
    {
        path: '/',
        component: Layout,
        children: [
            {
                path: '/systemTools',
                name: 'systemTools',
                component: systemTools,
                mata: {
                    title: '系统工具',
                    keepAlive: true
                },
                clildren: [
                    {
                        path: 'autoCode',
                        name: 'autoCode',
                        component: autoCode,
                        mata: {
                            title: '代码生成器',
                            keepAlive: true
                        }
                    },
                    {
                        path: 'formCreate',
                        name: 'formCreate',
                        component: formCreate,
                        mata: {
                            title: '表单生成器',
                            keepAlive: true
                        }
                    }
                ]
            }
        ]
    }
    // {
    //     path: '/',
    //     name: 'systemTools',
    //     component: Layout,
    //     clildren: [
    //         {
    //             path: '/systemTools/autoCode',
    //             name: 'autoCode',
    //             component: autoCode,
    //             mata: {
    //                 title: '代码生成器',
    //                 keepAlive: true
    //             }
    //         },
    //         {
    //             path: '/systemTools/formCreate',
    //             name: 'formCreate',
    //             component: formCreate,
    //             mata: {
    //                 title: '表单生成器',
    //                 keepAlive: true
    //             }
    //         }
    //     ]
    // },
]

const createRouter = () => new Router({
    routes: baseRouters
})

const router = createRouter()

export default router