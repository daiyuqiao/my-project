<template>
    <div>
    <el-scrollbar style="height:calc(100vh - 64px)">
      <transition :duration="{ enter: 800, leave: 100 }" mode="out-in" name="el-fade-in-linear">
        <el-menu
          :collapse="isCollapse"
          :collapse-transition="true"
          :default-active="active"
          @select="selectMenuItem"
          active-text-color="#fff"
          class="el-menu-vertical"
          text-color="rgb(191, 203, 217)"
          unique-opened
        >
          <el-menu-item index="/superAdmin">
            <i class="el-icon-user-solid"></i>
            <span slot="title">超级管理员</span>
          </el-menu-item>
          <el-submenu ref="subMenu" index="systemTools">
            <template slot="title">
                <i class="el-icon-s-cooperation"></i>
                <span slot="title">系统工具</span>
            </template>
            <el-menu-item index="/systemTools/autoCode">
            <i class="el-icon-cpu"></i>
            <span slot="title">代码生成器</span>
          </el-menu-item>
          <el-menu-item index="/systemTools/formCreate">
            <i class="el-icon-magic-stick"></i>
            <span slot="title">表单生成器</span>
          </el-menu-item>
         </el-submenu>
        </el-menu>
      </transition>
    </el-scrollbar>
  </div>
</template>

<script>
    export default {
        name: 'Aside',
        props: {
          isCollapse: Boolean
        },
        data () {
            return {
                active: 'superAdmin',
                // isCollapse: false
            }
        },
        methods: {
            selectMenuItem(index) {
                if (index === this.$route.path) return
                this.$router.push({ path: index })
                console.log(this.$route,index,'route');
            }
        },
        created() {
            this.active = this.$route.path
            let screenWidth = document.body.clientWidth
            if (screenWidth < 1000) {
                this.isCollapse = !this.isCollapse
            }
        },
        watch: {
            $route() {
              this.active = this.$route.name
            }
        }
    }
</script>

<style lang="scss">
.el-scrollbar {
  .el-scrollbar__view {
    height: 100%;
  }
}
.menu-info {
  .menu-contorl {
    line-height: 52px;
    font-size: 20px;
    display: table-cell;
    vertical-align: middle;
  }
}
</style>