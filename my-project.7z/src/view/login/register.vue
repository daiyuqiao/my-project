<template>

</template>

<script>
    export default {
        name: 'Register'
    }
</script>

<style>

</style>