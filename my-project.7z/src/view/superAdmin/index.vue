<template>
    <div>
        <h1>超级管理员</h1>
    </div>
</template>

<script>
    export default {
        name: 'superAdmin'
    }
</script>

<style lang="scss">
</style>
