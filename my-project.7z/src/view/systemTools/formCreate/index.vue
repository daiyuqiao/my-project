<template>
    <div>
        <h1>表单生成器</h1>
    </div>
</template>

<script>
    export default {
        name: 'formCreate'
    }
</script>

<style lang="scss">
</style>