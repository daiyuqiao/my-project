<template>
    <div>
        <h1>系统工具</h1>
    </div>
</template>

<script>
    export default {
        name: 'systemTools'
    }
</script>

<style lang="scss">
</style>