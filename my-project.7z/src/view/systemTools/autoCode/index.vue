<template>
    <div>
        <h1>代码生成器</h1>
    </div>
</template>

<script>
    export default {
        name: 'autoCode'
    }
</script>

<style lang="scss">
</style>